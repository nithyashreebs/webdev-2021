<?php


if(isset($_POST["submit"])){
        $cpid= $_POST['cpid'];
        $ccost = $_POST['ccost'];
        //$item = $_POST['item'];
        $database = "supermarket";
        $db = mysqli_connect('localhost','root','',$database);

        $result = $db->query("SELECT count(1) FROM cart where pid=$cpid");
        $row = mysqli_fetch_array($result);

        $total = $row[0];

        $count = "SELECT no_of_items from products where ID=$cpid";
        $row2 = $db->query($count);
        $row1 = mysqli_fetch_assoc($row2);
        
        if($row1['no_of_items']<1){
            header('Location: page3.php');
        }
        else{

        if($total == 0 ){

            $prd= "UPDATE products set no_of_items=no_of_items-1 where ID=$cpid";
            $prd1= $db->query($prd);

            $q = "INSERT INTO cart VALUES('',1,$cpid,1,$ccost)";
            $insert = $db->query($q);
        if($insert){
            echo "File uploaded successfully.";
            //header('Location: products.php');

        }else{
            echo "File upload failed, please try again.";
        } 
        }
        else{
            $prd= "UPDATE products set no_of_items=no_of_items where ID=$cpid";
            $prd1= $db->query($prd);

            $q1= "UPDATE cart set no_of_items = no_of_items+1 WHERE pid = $cpid";
            $update = $db->query($q1);
            //header('Location: products.php');
        }
    }
    
    if(isset($_SERVER["HTTP_REFERER"])){
        header("Location: {$_SERVER["HTTP_REFERER"]}");}
}
elseif(isset($_POST["sub"])){
    
    $cpid= $_POST['cpid2'];
    $ccost = $_POST['ccost2'];
    //$item = $_POST['item'];
    $database = "supermarket";
    $db = mysqli_connect('localhost','root','',$database);

    $result = $db->query("SELECT count(1) FROM cart where pid=$cpid");
    $row = mysqli_fetch_array($result);

    $total = $row[0];

    $count = "SELECT no_of_items from vegies where ID=$cpid";
    $row2 = $db->query($count);
    $row1 = mysqli_fetch_assoc($row2);
    
    if($row1['no_of_items']<1){
        echo "Item not available";
    }
    else{

    if($total == 0 ){
        $prd= "UPDATE vegies set no_of_items=no_of_items-1 where ID=$cpid";
        $prd1= $db->query($prd);
        $x = "INSERT INTO cart VALUES('',1,$cpid,1,$ccost)";
        $insert = $db->query($x);
    if($insert){
        echo "File uploaded successfully.";
        //header('Location: products.php');

    }else{
        echo "File upload failed, please try again.";
    } 
    }
    else{
        $prd= "UPDATE vegies set no_of_items=no_of_items where ID=$cpid";
        $prd1= $db->query($prd);

        $x1= "UPDATE cart set no_of_items = no_of_items + 1 WHERE pid = $cpid";
        $update = $db->query($x1);
        //header('Location: products.php');
    }
}

if(isset($_SERVER["HTTP_REFERER"])){
    header("Location: {$_SERVER["HTTP_REFERER"]}");}
}

else{
    echo "Not working";
}
?>


