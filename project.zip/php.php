<?php
$server = 'localhost';
$user = 'root';
$pass = '';
$db_name='supermarket';

	try {
		$pdo= new PDO("mysql:host={$server};dbname={$db_name}",$user,$pass);
		$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	}catch(PDOException $e){
		echo $e->getMessage();
	}

?>