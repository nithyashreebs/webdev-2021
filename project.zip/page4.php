<?php
ob_start();
require_once "php.php";
session_start();
ob_end_flush();
?>
<html>
    <head>
        <title>PERSONAL CARE</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="page3.css" rel="stylesheet" type="text/css">
       <script type="text/javascript" src="js.js"></script>
       <style>
         body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}

/* Style the tab content (and add height:100% for full page content) */
.content {
  color: black;
  display:block;
  padding: 100px 20px;
  height: 100%;
  font-family: gabriola;
  font-size:30px;
  }
  .food{
    font-size:50px;
    font-family: 'curlz MT';
    font-weight:bolder;
    color:darkgoldenrod;
    text-align:center;
  }
  .table{
    font-size:25px;
    border:2px solid black;
  }
  .basket{
    float:right;
    padding-right:20px;
  }
  .head{
    background: linear-gradient( to bottom, #ba70ff 0%, #fd8a94 100%);
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 18px;
  font-size: 15px;
  width: 100%;
  text-align:center;
  }
  .names{
  color:rgb(201, 159, 52);
  font-size:20px;
  font-family:'curlz MT';
  }
  .f{
    text-align:center;
  }</style>
    </head>
    <body>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <div class="food">PERSONAL CARE</div><div class="f"><a href="page3.php" class="names">FOOD</a>||<a href="page5.php"class="names">HOUSEHOLD ITEMS</a>||<a href="page6.php"class="names">TOYS & STATIONERIES</a></div>   
      <a href="show_cart.php"><div class="basket"><i class="fa fa-shopping-basket" style="font-size:30PX"></i></div></a><br><br>
        
  <div class="head">FACE PRODUCTS</div>  
 <div class="content">
  
  	<?php
   $db="supermarket";
   $connect = mysqli_connect('localhost','root','',$db);
   $query = mysqli_query($connect,"SELECT * FROM face");
   
   
      echo "<center>";
      ?><table cellpadding="5" cellspacing="5" class="table">
      	<?php
      echo "<tr>";
      echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Product ID"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Catogery"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Item_name"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Cost of each item"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "No_of_items"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      
      echo "<th>";echo "&nbsp"; echo "&nbsp"; echo "cart"; echo "&nbsp"; echo "&nbsp";echo "</th>";
      echo "</td>";
      echo "</tr>";
 while ($row = mysqli_fetch_array ($query)) {
      echo "<tr>";
      echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["ID"];echo "&nbsp"; echo "&nbsp"; echo "</td>";
      echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["catogery"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
      echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["Item_name"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
      echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["cost"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
      echo "<td>";echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp"; echo $row["no_of_items"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
      echo "<td>"; ?><form action="add_to_cart1.php" method="post" enctype="multipart/form-data">
      	<input type="hidden" name="cpid2" value='<?php echo $row["ID"];?>'/>
      	<input type="hidden" name="ccost2" value='<?php echo $row["cost"];?>'/>
      	
        <input type="submit" name="sub" value="ADD"/>
    </form>
      <?php echo "</td>";
      
      echo "</tr>";
  }

  echo "</table>";
  echo "</center>";
?>
</div>
<div class="head">SOAP & SHAMPOO</div> 
<div class="content">
  
  <?php
 $db="supermarket";
 $connect = mysqli_connect('localhost','root','',$db);
 $query = mysqli_query($connect,"SELECT * FROM shampoo");
 
 
    echo "<center>";
    ?><table cellpadding="5" cellspacing="5" class="table">
      <?php
    echo "<tr>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Product ID"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Catogery"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Item_name"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Cost of each item"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "No_of_items"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    
    echo "<th>";echo "&nbsp"; echo "&nbsp"; echo "cart"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "</td>";
    echo "</tr>";
while ($row = mysqli_fetch_array ($query)) {
    echo "<tr>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["ID"];echo "&nbsp"; echo "&nbsp"; echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["catogery"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["Item_name"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["cost"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>";echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp"; echo $row["no_of_items"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; ?><form action="add_to_cart.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="cpid" value='<?php echo $row["ID"];?>'/>
      <input type="hidden" name="ccost" value='<?php echo $row["cost"];?>'/>
      
      <input type="submit" name="submit" value="ADD"/>
  </form>
    <?php echo "</td>";
    
    echo "</tr>";
}

echo "</table>";
echo "</center>";
?>
</div>
<div class="head">PASTE, BRUSH AND OTHERS</div> 
<div class="content" >
  
  <?php
 $db="supermarket";
 $connect = mysqli_connect('localhost','root','',$db);
 $query = mysqli_query($connect,"SELECT * FROM paste");
 
 
    echo "<center>";
    ?><table cellpadding="5" cellspacing="5" class="table">
      <?php
    echo "<tr>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Product ID"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Catogery"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Item_name"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "Cost of each item"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "<th>"; echo "&nbsp"; echo "&nbsp";echo "No_of_items"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    
    echo "<th>";echo "&nbsp"; echo "&nbsp"; echo "cart"; echo "&nbsp"; echo "&nbsp";echo "</th>";
    echo "</td>";
    echo "</tr>";
while ($row = mysqli_fetch_array ($query)) {
    echo "<tr>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["ID"];echo "&nbsp"; echo "&nbsp"; echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["catogery"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["Item_name"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp";echo $row["cost"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>";echo "&nbsp"; echo "&nbsp";echo "&nbsp"; echo "&nbsp"; echo $row["no_of_items"]; echo "&nbsp"; echo "&nbsp";echo "</td>";
    echo "<td>"; ?><form action="add_to_cart.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="cpid" value='<?php echo $row["ID"];?>'/>
      <input type="hidden" name="ccost" value='<?php echo $row["cost"];?>'/>
      
      <input type="submit" name="submit" value="ADD"/>
  </form>
    <?php echo "</td>";
    
    echo "</tr>";
}

echo "</table>";
echo "</center>";
?>
</div>



<script>
    function openPage(pageName, elmnt) {
        // Hide all elements with class="tabcontent" by default */
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "block";
        }
      
        // Remove the background color of all tablinks/buttons
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].style.backgroundColor = "";
        }
      
        // Show the specific tab content
        document.getElementById(pageName).style.display = "block";
      
      }
      
      // Get the element with id="defaultOpen" and click on it
       document.getElementById("defaultOpen").click();
       </script>
	      </body>
      </html>
